##########################################################
#
# Script: options.py
# Author: Jani Hirvinen, <jani@jdronics.fi>
# Date: 2024-04-07
# Version: 1.0
#
# Description: python options file for KiCad QIHE plugin
#
# Works:
#  - Windows/Cywin
#  - Linux
#  - MacOS
#

# Options file

